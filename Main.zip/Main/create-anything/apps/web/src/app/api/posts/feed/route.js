import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const url = new URL(request.url);
    const limit = parseInt(url.searchParams.get("limit")) || 20;
    const offset = parseInt(url.searchParams.get("offset")) || 0;

    // Get posts from users the current user follows + their own posts
    const posts = await sql`
      SELECT 
        p.id,
        p.content,
        p.image_urls,
        p.video_url,
        p.likes_count,
        p.comments_count,
        p.created_at,
        u.id as user_id,
        u.username,
        u.name,
        u.avatar_url,
        CASE WHEN l.id IS NOT NULL THEN true ELSE false END as isLiked
      FROM posts p
      INNER JOIN auth_users u ON p.user_id = u.id
      LEFT JOIN follows f ON f.following_id = p.user_id AND f.follower_id = ${userId}
      LEFT JOIN likes l ON l.post_id = p.id AND l.user_id = ${userId}
      WHERE p.user_id = ${userId} OR f.id IS NOT NULL
      ORDER BY p.created_at DESC
      LIMIT ${limit}
      OFFSET ${offset}
    `;

    const formattedPosts = posts.map((post) => ({
      id: post.id,
      content: post.content,
      image_urls: post.image_urls,
      video_url: post.video_url,
      likes_count: post.likes_count,
      comments_count: post.comments_count,
      created_at: post.created_at,
      isLiked: post.isliked,
      user: {
        id: post.user_id,
        username: post.username,
        name: post.name,
        avatar_url: post.avatar_url,
      },
    }));

    return Response.json({ posts: formattedPosts });
  } catch (err) {
    console.error("GET /api/posts/feed error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
