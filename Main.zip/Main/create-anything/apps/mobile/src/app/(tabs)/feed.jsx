import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
} from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import {
  Heart,
  MessageCircle,
  Send,
  Bookmark,
  MoreHorizontal,
} from "lucide-react-native";
import { useAuth } from "@/utils/auth/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

export default function FeedScreen() {
  const insets = useSafeAreaInsets();
  const { isAuthenticated, auth, signIn } = useAuth();
  const [refreshing, setRefreshing] = useState(false);
  const queryClient = useQueryClient();

  // Fetch posts
  const { data: posts = [], isLoading } = useQuery({
    queryKey: ["feed"],
    queryFn: async () => {
      const response = await fetch("/api/posts/feed");
      if (!response.ok) throw new Error("Failed to fetch feed");
      const data = await response.json();
      return data.posts || [];
    },
    enabled: isAuthenticated,
  });

  // Fetch stories
  const { data: stories = [] } = useQuery({
    queryKey: ["stories"],
    queryFn: async () => {
      const response = await fetch("/api/stories");
      if (!response.ok) throw new Error("Failed to fetch stories");
      const data = await response.json();
      return data.stories || [];
    },
    enabled: isAuthenticated,
  });

  // Like mutation
  const likeMutation = useMutation({
    mutationFn: async ({ postId, isLiked }) => {
      const response = await fetch(`/api/posts/${postId}/like`, {
        method: isLiked ? "DELETE" : "POST",
      });
      if (!response.ok) throw new Error("Failed to update like");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["feed"] });
    },
  });

  const onRefresh = async () => {
    setRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ["feed"] });
    await queryClient.invalidateQueries({ queryKey: ["stories"] });
    setRefreshing(false);
  };

  const handleLike = (postId, isLiked) => {
    likeMutation.mutate({ postId, isLiked });
  };

  const formatTimeAgo = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 60) return `${diffMins}m`;
    if (diffHours < 24) return `${diffHours}h`;
    return `${diffDays}d`;
  };

  // Show sign in if not authenticated
  if (!isAuthenticated) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "white",
          paddingTop: insets.top,
          justifyContent: "center",
          alignItems: "center",
          padding: 20,
        }}
      >
        <StatusBar style="dark" />
        <Text
          style={{
            fontSize: 32,
            fontWeight: "bold",
            textAlign: "center",
            marginBottom: 10,
            color: "#8B5CF6",
          }}
        >
          EchoChat
        </Text>
        <Text
          style={{
            fontSize: 16,
            color: "#6B7280",
            textAlign: "center",
            marginBottom: 30,
          }}
        >
          Connect with friends and share your moments
        </Text>
        <TouchableOpacity
          onPress={() => signIn()}
          style={{
            backgroundColor: "#8B5CF6",
            paddingHorizontal: 24,
            paddingVertical: 12,
            borderRadius: 12,
          }}
        >
          <Text style={{ color: "white", fontSize: 16, fontWeight: "600" }}>
            Get Started
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "white" }}>
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 10,
          paddingHorizontal: 16,
          paddingBottom: 10,
          borderBottomWidth: 1,
          borderBottomColor: "#F3F4F6",
        }}
      >
        <Text
          style={{
            fontSize: 24,
            fontWeight: "bold",
            color: "#8B5CF6",
          }}
        >
          EchoChat
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        showsVerticalScrollIndicator={false}
      >
        {/* Stories */}
        {stories.length > 0 && (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={{ padding: 16 }}
            contentContainerStyle={{ gap: 12 }}
          >
            {stories.map((story) => (
              <TouchableOpacity key={story.id} style={{ alignItems: "center" }}>
                <View
                  style={{
                    width: 60,
                    height: 60,
                    borderRadius: 30,
                    borderWidth: 2,
                    borderColor: "#8B5CF6",
                    padding: 2,
                  }}
                >
                  <Image
                    source={{
                      uri:
                        story.image_url ||
                        story.user?.avatar_url ||
                        "https://via.placeholder.com/60",
                    }}
                    style={{ width: 54, height: 54, borderRadius: 27 }}
                    contentFit="cover"
                  />
                </View>
                <Text
                  style={{
                    fontSize: 12,
                    marginTop: 4,
                    color: "#374151",
                    maxWidth: 60,
                  }}
                  numberOfLines={1}
                >
                  {story.user?.username || "You"}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        )}

        {/* Posts */}
        {posts.map((post) => (
          <View key={post.id} style={{ marginBottom: 20 }}>
            {/* Post Header */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                paddingHorizontal: 16,
                paddingVertical: 12,
              }}
            >
              <Image
                source={{
                  uri:
                    post.user?.avatar_url || "https://via.placeholder.com/40",
                }}
                style={{ width: 40, height: 40, borderRadius: 20 }}
                contentFit="cover"
              />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={{ fontWeight: "600", color: "#111827" }}>
                  {post.user?.username || "Unknown User"}
                </Text>
                <Text style={{ fontSize: 12, color: "#6B7280" }}>
                  {formatTimeAgo(post.created_at)}
                </Text>
              </View>
              <TouchableOpacity>
                <MoreHorizontal size={20} color="#6B7280" />
              </TouchableOpacity>
            </View>

            {/* Post Image */}
            {post.image_urls && post.image_urls.length > 0 && (
              <Image
                source={{ uri: post.image_urls[0] }}
                style={{ width: "100%", aspectRatio: 1 }}
                contentFit="cover"
              />
            )}

            {/* Post Actions */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                paddingHorizontal: 16,
                paddingVertical: 12,
                gap: 16,
              }}
            >
              <TouchableOpacity
                onPress={() => handleLike(post.id, post.isLiked)}
              >
                <Heart
                  size={24}
                  color={post.isLiked ? "#EF4444" : "#111827"}
                  fill={post.isLiked ? "#EF4444" : "transparent"}
                />
              </TouchableOpacity>
              <TouchableOpacity>
                <MessageCircle size={24} color="#111827" />
              </TouchableOpacity>
              <TouchableOpacity>
                <Send size={24} color="#111827" />
              </TouchableOpacity>
              <View style={{ flex: 1 }} />
              <TouchableOpacity>
                <Bookmark size={24} color="#111827" />
              </TouchableOpacity>
            </View>

            {/* Post Content */}
            <View style={{ paddingHorizontal: 16 }}>
              {post.likes_count > 0 && (
                <Text style={{ fontWeight: "600", marginBottom: 4 }}>
                  {post.likes_count} {post.likes_count === 1 ? "like" : "likes"}
                </Text>
              )}
              {post.content && (
                <Text style={{ color: "#111827", lineHeight: 20 }}>
                  <Text style={{ fontWeight: "600" }}>
                    {post.user?.username}{" "}
                  </Text>
                  {post.content}
                </Text>
              )}
              {post.comments_count > 0 && (
                <TouchableOpacity style={{ marginTop: 4 }}>
                  <Text style={{ color: "#6B7280" }}>
                    View all {post.comments_count} comments
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        ))}

        {isLoading && (
          <View style={{ padding: 40, alignItems: "center" }}>
            <Text style={{ color: "#6B7280" }}>Loading posts...</Text>
          </View>
        )}

        {!isLoading && posts.length === 0 && (
          <View style={{ padding: 40, alignItems: "center" }}>
            <Text style={{ color: "#6B7280", textAlign: "center" }}>
              No posts yet. Follow some users or create your first post!
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
