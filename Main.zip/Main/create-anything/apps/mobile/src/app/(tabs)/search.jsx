import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { Search as SearchIcon } from "lucide-react-native";
import { useAuth } from "@/utils/auth/useAuth";
import { useQuery } from "@tanstack/react-query";

export default function SearchScreen() {
  const insets = useSafeAreaInsets();
  const { isAuthenticated, signIn } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  // Search users
  const { data: searchResults = [], isLoading } = useQuery({
    queryKey: ["search", searchQuery],
    queryFn: async () => {
      if (!searchQuery.trim()) return [];
      const response = await fetch(
        `/api/users/search?q=${encodeURIComponent(searchQuery.trim())}`,
      );
      if (!response.ok) throw new Error("Failed to search users");
      const data = await response.json();
      return data.users || [];
    },
    enabled: !!searchQuery.trim() && isAuthenticated,
  });

  // Get suggested users
  const { data: suggestedUsers = [] } = useQuery({
    queryKey: ["suggestedUsers"],
    queryFn: async () => {
      const response = await fetch("/api/users/suggested");
      if (!response.ok) throw new Error("Failed to fetch suggested users");
      const data = await response.json();
      return data.users || [];
    },
    enabled: isAuthenticated,
  });

  // Show sign in if not authenticated
  if (!isAuthenticated) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "white",
          paddingTop: insets.top,
          justifyContent: "center",
          alignItems: "center",
          padding: 20,
        }}
      >
        <StatusBar style="dark" />
        <SearchIcon size={60} color="#8B5CF6" style={{ marginBottom: 20 }} />
        <Text
          style={{
            fontSize: 24,
            fontWeight: "bold",
            textAlign: "center",
            marginBottom: 10,
            color: "#374151",
          }}
        >
          Discover People
        </Text>
        <Text
          style={{
            fontSize: 16,
            color: "#6B7280",
            textAlign: "center",
            marginBottom: 30,
          }}
        >
          Find and connect with friends
        </Text>
        <TouchableOpacity
          onPress={() => signIn()}
          style={{
            backgroundColor: "#8B5CF6",
            paddingHorizontal: 24,
            paddingVertical: 12,
            borderRadius: 12,
          }}
        >
          <Text style={{ color: "white", fontSize: 16, fontWeight: "600" }}>
            Get Started
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "white" }}>
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 10,
          paddingHorizontal: 16,
          paddingBottom: 10,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: "#F3F4F6",
            borderRadius: 12,
            paddingHorizontal: 12,
            paddingVertical: 8,
          }}
        >
          <SearchIcon size={20} color="#6B7280" />
          <TextInput
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Search users..."
            style={{
              flex: 1,
              marginLeft: 8,
              fontSize: 16,
              color: "#111827",
            }}
            placeholderTextColor="#6B7280"
          />
        </View>
      </View>

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        {/* Search Results */}
        {searchQuery.trim() && (
          <View style={{ paddingHorizontal: 16 }}>
            <Text
              style={{
                fontSize: 18,
                fontWeight: "600",
                marginBottom: 16,
                color: "#111827",
              }}
            >
              Search Results
            </Text>

            {isLoading ? (
              <View style={{ padding: 20, alignItems: "center" }}>
                <Text style={{ color: "#6B7280" }}>Searching...</Text>
              </View>
            ) : searchResults.length > 0 ? (
              searchResults.map((user) => (
                <TouchableOpacity
                  key={user.id}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    paddingVertical: 12,
                    borderBottomWidth: 1,
                    borderBottomColor: "#F3F4F6",
                  }}
                >
                  <Image
                    source={{
                      uri: user.avatar_url || "https://via.placeholder.com/50",
                    }}
                    style={{ width: 50, height: 50, borderRadius: 25 }}
                    contentFit="cover"
                  />
                  <View style={{ flex: 1, marginLeft: 12 }}>
                    <Text
                      style={{
                        fontWeight: "600",
                        fontSize: 16,
                        color: "#111827",
                      }}
                    >
                      {user.username}
                    </Text>
                    <Text
                      style={{
                        color: "#6B7280",
                        fontSize: 14,
                      }}
                    >
                      {user.name}
                    </Text>
                    {user.bio && (
                      <Text
                        style={{
                          color: "#6B7280",
                          fontSize: 12,
                          marginTop: 2,
                        }}
                        numberOfLines={1}
                      >
                        {user.bio}
                      </Text>
                    )}
                  </View>
                  <TouchableOpacity
                    style={{
                      backgroundColor: "#8B5CF6",
                      paddingHorizontal: 16,
                      paddingVertical: 6,
                      borderRadius: 8,
                    }}
                  >
                    <Text
                      style={{
                        color: "white",
                        fontWeight: "600",
                        fontSize: 14,
                      }}
                    >
                      Follow
                    </Text>
                  </TouchableOpacity>
                </TouchableOpacity>
              ))
            ) : (
              <View style={{ padding: 20, alignItems: "center" }}>
                <Text style={{ color: "#6B7280" }}>No users found</Text>
              </View>
            )}
          </View>
        )}

        {/* Suggested Users */}
        {!searchQuery.trim() && (
          <View style={{ paddingHorizontal: 16 }}>
            <Text
              style={{
                fontSize: 18,
                fontWeight: "600",
                marginBottom: 16,
                color: "#111827",
              }}
            >
              Suggested for You
            </Text>

            {suggestedUsers.length > 0 ? (
              <View
                style={{
                  flexDirection: "row",
                  flexWrap: "wrap",
                  gap: 16,
                }}
              >
                {suggestedUsers.map((user) => (
                  <View
                    key={user.id}
                    style={{
                      backgroundColor: "#F9FAFB",
                      borderRadius: 12,
                      padding: 16,
                      alignItems: "center",
                      width: "45%",
                      borderWidth: 1,
                      borderColor: "#E5E7EB",
                    }}
                  >
                    <Image
                      source={{
                        uri:
                          user.avatar_url || "https://via.placeholder.com/60",
                      }}
                      style={{ width: 60, height: 60, borderRadius: 30 }}
                      contentFit="cover"
                    />
                    <Text
                      style={{
                        fontWeight: "600",
                        fontSize: 14,
                        color: "#111827",
                        marginTop: 8,
                        textAlign: "center",
                      }}
                      numberOfLines={1}
                    >
                      {user.username}
                    </Text>
                    <Text
                      style={{
                        color: "#6B7280",
                        fontSize: 12,
                        textAlign: "center",
                        marginTop: 2,
                      }}
                      numberOfLines={1}
                    >
                      {user.name}
                    </Text>
                    <TouchableOpacity
                      style={{
                        backgroundColor: "#8B5CF6",
                        paddingHorizontal: 16,
                        paddingVertical: 6,
                        borderRadius: 8,
                        marginTop: 8,
                      }}
                    >
                      <Text
                        style={{
                          color: "white",
                          fontWeight: "600",
                          fontSize: 12,
                        }}
                      >
                        Follow
                      </Text>
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            ) : (
              <View style={{ padding: 20, alignItems: "center" }}>
                <Text style={{ color: "#6B7280" }}>
                  No suggestions available
                </Text>
              </View>
            )}
          </View>
        )}
      </ScrollView>
    </View>
  );
}
