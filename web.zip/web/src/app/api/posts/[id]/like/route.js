import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request, { params }) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const postId = params.id;

    // Check if post exists
    const post = await sql`
      SELECT id FROM posts WHERE id = ${postId} LIMIT 1
    `;

    if (post.length === 0) {
      return Response.json({ error: "Post not found" }, { status: 404 });
    }

    // Check if already liked
    const existingLike = await sql`
      SELECT id FROM likes WHERE user_id = ${userId} AND post_id = ${postId} LIMIT 1
    `;

    if (existingLike.length > 0) {
      return Response.json({ error: "Post already liked" }, { status: 400 });
    }

    // Create like
    await sql`
      INSERT INTO likes (user_id, post_id)
      VALUES (${userId}, ${postId})
    `;

    // Create notification for post owner
    const postOwner = await sql`
      SELECT user_id FROM posts WHERE id = ${postId}
    `;

    if (postOwner[0] && postOwner[0].user_id !== userId) {
      await sql`
        INSERT INTO notifications (user_id, type, actor_id, post_id, message)
        VALUES (${postOwner[0].user_id}, 'like', ${userId}, ${postId}, 'liked your post')
      `;
    }

    return Response.json({ success: true });
  } catch (err) {
    console.error("POST /api/posts/[id]/like error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const postId = params.id;

    // Delete like
    const result = await sql`
      DELETE FROM likes 
      WHERE user_id = ${userId} AND post_id = ${postId}
      RETURNING id
    `;

    if (result.length === 0) {
      return Response.json({ error: "Like not found" }, { status: 404 });
    }

    return Response.json({ success: true });
  } catch (err) {
    console.error("DELETE /api/posts/[id]/like error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
