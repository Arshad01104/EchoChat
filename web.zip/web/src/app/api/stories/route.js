import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;

    // Get stories from users the current user follows + their own stories
    // Only get stories that haven't expired (within 24 hours)
    const stories = await sql`
      SELECT 
        s.id,
        s.image_url,
        s.video_url,
        s.text_content,
        s.created_at,
        s.expires_at,
        u.id as user_id,
        u.username,
        u.name,
        u.avatar_url
      FROM stories s
      INNER JOIN auth_users u ON s.user_id = u.id
      LEFT JOIN follows f ON f.following_id = s.user_id AND f.follower_id = ${userId}
      WHERE (s.user_id = ${userId} OR f.id IS NOT NULL)
        AND s.expires_at > NOW()
      ORDER BY s.created_at DESC
    `;

    const formattedStories = stories.map((story) => ({
      id: story.id,
      image_url: story.image_url,
      video_url: story.video_url,
      text_content: story.text_content,
      created_at: story.created_at,
      expires_at: story.expires_at,
      user: {
        id: story.user_id,
        username: story.username,
        name: story.name,
        avatar_url: story.avatar_url,
      },
    }));

    return Response.json({ stories: formattedStories });
  } catch (err) {
    console.error("GET /api/stories error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const body = await request.json();
    const { image_url, video_url, text_content } = body;

    if (!image_url && !video_url && !text_content) {
      return Response.json(
        {
          error: "Story must have image, video, or text content",
        },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO stories (user_id, image_url, video_url, text_content)
      VALUES (${userId}, ${image_url || null}, ${video_url || null}, ${text_content || null})
      RETURNING id, image_url, video_url, text_content, created_at, expires_at
    `;

    const story = result[0];
    return Response.json({ story });
  } catch (err) {
    console.error("POST /api/stories error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
